# What does this mod do?..
## Changes all the animals in the ThiccCompanyModelReplacer Mod to Orange.